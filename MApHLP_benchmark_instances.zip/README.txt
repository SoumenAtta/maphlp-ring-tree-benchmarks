MApHLP benchmark instances
==========================

This archive contains the 11 data files used in the manuscript.
Each .dat file contains query-volume matrix Q and distance matrix D.
n = number of demand/candidate nodes; p = number of segments/hubs.
alpha = inter-hub cost multiplier (0.2, 0.4, 0.6, 0.8, or 1.0).
alpha and the ring/tree topology are model settings, not separate data files.
The case_manifest.csv maps all 110 cases to their data files and BKS values.
BKS is the smallest feasible cost found among the methods in the study.
gurobi_certified=1 means certified within relative MIP gap 1e-4.
